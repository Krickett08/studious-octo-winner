<?php

namespace DefStudio\Telegraph\Enums;

class Emojis
{
    public const DICE = '🎲';
    public const ARROW = '🎯';
    public const BASKETBALL = '🏀';
    public const FOOTBALL = '⚽';
    public const BOWLING = '🎳';
    public const SLOT_MACHINE = '🎰';
}
