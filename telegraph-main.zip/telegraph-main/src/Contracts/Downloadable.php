<?php

namespace DefStudio\Telegraph\Contracts;

interface Downloadable
{
    public function id(): string;
}
