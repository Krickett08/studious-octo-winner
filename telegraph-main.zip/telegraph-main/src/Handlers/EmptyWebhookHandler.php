<?php

namespace DefStudio\Telegraph\Handlers;

class EmptyWebhookHandler extends WebhookHandler
{
}
